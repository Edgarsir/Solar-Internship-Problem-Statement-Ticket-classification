import streamlit as st
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences
import numpy as np
import pickle

# Global variables for the model, tokenizer, and label encoder
model = None
tokenizer = None
label_encoder = None

# Function to load resources (model, tokenizer, and label encoder)
def load_resources():
    global model, tokenizer, label_encoder
    
    # Load the model if not already loaded
    if model is None:
        model = load_model('ticket_inquiry_rnn_model.h5')
    
    # Load the tokenizer
    if tokenizer is None:
        with open('tokenizer.pkl', 'rb') as f:
            tokenizer = pickle.load(f)
    
    # Load the label encoder
    if label_encoder is None:
        with open('label_encoder.pkl', 'rb') as f:
            label_encoder = pickle.load(f)

# Streamlit app setup
st.title("Customer Ticket Type Prediction")

# Input fields for the user
ticket_description = st.text_area("Enter the Ticket Description", "")
product_purchased = st.text_input("Enter the Product Purchased", "")

# Button to make prediction
if st.button("Predict Ticket Type"):
    if ticket_description and product_purchased:
        # Load resources on demand
        load_resources()

        # Combine the text fields for prediction
        ticket_text = ticket_description + " " + product_purchased

        # Preprocess the input
        sequence = tokenizer.texts_to_sequences([ticket_text])
        padded_sequence = pad_sequences(sequence, padding='post', maxlen=200)

        # Predict ticket type
        prediction = model.predict(padded_sequence)
        predicted_label = np.argmax(prediction, axis=1)[0]
        predicted_ticket_type = label_encoder.inverse_transform([predicted_label])[0]

        # Display the prediction result
        st.success(f"The predicted ticket type is: {predicted_ticket_type}")
    else:
        st.warning("Please provide both ticket description and product purchased.")
